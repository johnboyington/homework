// interpolate
double interpolate(double x_new, double *x, int xx, double *y, int yy, int n, int order);
